### this code deliberately uses a lot of if-else constructs for demonstration; actually it could be much simpler
import random
# create a random arrangment of what's hiding behind the three doors
behind_doors = ['goat', 'goat', 'car']
random.shuffle(behind_doors)

# ask user to make a choice of doors
choice =int(input('Enter the number of door (1/2/3): '))

# now unveil a goat that is not behind the chosen door

if behind_doors[choice-1] == 'car': # if the choice is car, we can choose either of the two other doors randomly (note: subtract one from choice to have it as index)
    if choice == 1:
        random_goat_door = random.choice([2, 3])
        print('There is a goat behind door ', random_goat_door, '.', sep = '')
        # since we showed that there is a goat behind this door, the other remains as alternative choice
        if random_goat_door == 2: # if we showed door 2, door 3 can be chosen as an alternative
            alternative_choice = 3
        else: # if not door 2, then we showed door 3, so the alternative is door 2
            alternative_choice = 2
    elif choice == 2: # same logic as for door 1
        random_goat_door = random.choice([1, 3])
        print('There is a goat behind door ', random_goat_door, '.', sep = '')
        if random_goat_door == 1:
            alternative_choice = 3
        else:
            alternative_choice = 1
    else: # this will mean the choice of door 3
        random_goat_door = random.choice([1, 2])
        print('There is a goat behind door ', random_goat_door, '.', sep = '')
        if random_goat_door == 1:
            alternative_choice = 2
        else:
            alternative_choice = 1
else: # if the choice was a goat, then we need to show the door with the other goat
    if choice != 1 and behind_doors[0]=='goat': # if the choice was not door 1, and door 1 has goat behind it, then reveal it
        print('There is a goat behind door 1.')
        if choice == 2: # if door 2 was originally chosen, door 3 can be chosen as an alternative
            alternative_choice = 3
        else: # if not door 2, then we door 3 was originally chosen, so the alternative is door 2
            alternative_choice = 2
    elif choice != 2 and behind_doors[1]=='goat': # for door 2 same as for door 1
        print('There is a goat behind door 2.')
        if choice == 1:
            alternative_choice = 3
        else:
            alternative_choice = 1      
    else:  # if not door 1 or 2, then the unchosen door with the goat must be door 3
        print('There is a goat behind door 3.')
        if choice == 1:
            alternative_choice = 2
        else:
            alternative_choice = 1
        
# ask user to decide whether to stay with the originally chosen door or with the alternative

new_choice = int(input('\nPlease choose between the originally chosen (door ' + str(choice) + ') or the remaining alternative (door ' + str(alternative_choice) + '): '))

# show what we have behind the finally chosen door

print('You have won a', behind_doors[new_choice - 1])
