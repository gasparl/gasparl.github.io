#!/usr/bin/env python2
# -*- coding: utf-8 -*-
from psychopy.core import quit # this simply quits the experiment
from psychopy.gui import Dlg
from time import gmtime, strftime
testing = True

def start_input():
    global subj_id, dems, condition, key_location
    input_box = Dlg(title=u'Grunddaten', labelButtonOK=u'OK', labelButtonCancel=u'Abbrechen')
    input_box.addText(text=u'')
    input_box.addField(label=u'c.', tip = '1 - red/green; 2 - white/black; 3 - white/red; 4 - white/green; 5 - black/red; 6 - black/green')
    input_box.addField(label=u'o.', tip = '1 - pos/neg; 2 - neg/pos')
    input_box.addField(label=u'VP', tip = 'Ziffern')
    input_box.addText(text=u'')
    input_box.addText(text=u'Bitte ausfüllen:')
    input_box.addField(label=u'Geschlecht', initial = '', choices=[u'männlich',u'weiblich'] )
    input_box.addField(label=u'Alter', tip = 'Ziffern')
    input_box.addField(label=u'Herkunftsland', initial = '', choices=[u'Österreich',u'Deutschland',u'Schweiz'] ) # delete choices to have it open-ended
    input_box.addField(label=u'Händigkeit', initial = '', choices=[u'rechtshändig',u'linkshändig'], tip = '(bevorzugte Hand zum Schreiben)' )
    input_box.addText(text=u'')
    input_box.addText(text=u'Einverständniserklärung gelesen und zugestimmt')
    input_box.addText(text=u'')
    input_box.addText(text=u'')
    input_box.show()
    if input_box.OK:
        stop = False
        try:
            condition = int(input_box.data[0])
        except ValueError:
            condition = 999
            print("Condition must be a one-digit number!")
        # check if variables correctly given
        if condition not in [1,2,3,4,5,6]:
            if testing:
                condition = 1 # set value for testing to skip Dlg input box
                print("condition was not set, now set to " + str(condition) + " for testing.")
            else:
                print("condition was not set correctly (should be between 1-6)")
                stop = True

        try:
            key_location = int(input_box.data[1])
        except ValueError:
            key_location = 999
            print("Condition must be a one-digit number!")
        # check if variables correctly given
        if key_location not in [1,2]:
            if testing:
                key_location = 1 # set value for testing to skip Dlg input box
                print("key_location was not set, now set to " + str(key_location) + " for testing.")
            else:
                print("key_location was not set correctly (should be either 1 or 2)")
                stop = True
        try:
            subj_num = int(input_box.data[2])
        except ValueError:
            if testing:
                subj_num = 99 # set value for testing to skip Dlg input box
                print("subj_num was not set, now set to " + str(subj_num) + " for testing.")
            else:
                print("vp (subject number) was not set correctly (should be simple number)")
                stop = True
        try:
            age = int(input_box.data[4])
        except ValueError:
            if testing:
                age = 11 # set value for testing to skip Dlg input box
                print("age was not set, now set to " + str(age) + " for testing.")
            else:
                print("age was not set correctly (should be simple number)")
                stop = True
        if stop:
            print("\nTry again with correct inputs.\n")
            quit()
        subj_id = str(subj_num).zfill(3) + "_" + str(strftime("%Y%m%d%H%M%S", gmtime()))
        dems = subj_id + '\t' + input_box.data[3] + '\t' + str(age)  + '\t' + input_box.data[5]  + '\t' + input_box.data[6] + "\n"
    else:
        quit()
